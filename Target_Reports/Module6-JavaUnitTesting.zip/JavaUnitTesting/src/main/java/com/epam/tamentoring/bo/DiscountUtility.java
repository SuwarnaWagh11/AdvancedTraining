package com.epam.tamentoring.bo;

public interface DiscountUtility {
    double calculateDiscount(UserAccount userAccount);
}
