﻿namespace DotnetUnitTesting
{
    public interface IDiscountUtility
    {
        double CalculateDiscount(UserAccount userAccount);
    }
}